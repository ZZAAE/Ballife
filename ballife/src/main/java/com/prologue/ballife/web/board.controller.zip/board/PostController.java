package com.prologue.ballife.web.board;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.prologue.ballife.service.board.PostService;
import com.prologue.ballife.web.dto.board.PostDto;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Tag(name = "Post", description = "게시글 API")
@RestController
@RequestMapping("/api/posts")
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;

    // 게시글 작성
    @Operation(summary = "게시글 작성")
    @PostMapping
    public ResponseEntity<PostDto.PostResponse> createPost(
            @Valid @RequestBody PostDto.CreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(postService.createPost(request));
    }

    // 게시글 상세 조회
    @Operation(summary = "게시글 상세")
    @GetMapping("/{postId}")
    public ResponseEntity<PostDto.PostResponse> getPost(
            @PathVariable Long postId) {
        return ResponseEntity.ok(postService.getPost(postId));
    }

    // 조회수 증가
    @Operation(summary = "조회수 증가")
    @PostMapping("/{postId}/view")
    public ResponseEntity<Void> recordView(
            @PathVariable Long postId) {
        postService.recordView(postId);
        return ResponseEntity.noContent().build();
    }

    // 게시글 목록 조회 - 카테고리
    @Operation(summary = "카테고리별 게시글 목록 조회")
    @GetMapping("/category")
    public ResponseEntity<Page<PostDto.PostListResponse>> getPostsByCategory(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam String category) {
        return ResponseEntity.ok(postService.getPostsByCategory(page, size, category));
    }

    // 게시글 목록 조회 - 키워드 검색
    @Operation(summary = "키워드 검색 게시글 목록 조회")
    @GetMapping("/search")
    public ResponseEntity<Page<PostDto.PostListResponse>> getPostsByKeyword(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam String keyword) {
        return ResponseEntity.ok(postService.getPostsByKeyword(page, size, keyword));
    }

    // 게시글 목록 조회 - 카테고리 + 키워드
    @Operation(summary = "카테고리 + 키워드 게시글 목록 조회")
    @GetMapping("/filter")
    public ResponseEntity<Page<PostDto.PostListResponse>> getPostsByCategoryAndKeyword(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam String category,
            @RequestParam String keyword) {
        return ResponseEntity.ok(postService.getPostsByCategoryAndKeyword(page, size, category, keyword));
    }

    // 게시글 수정
    @Operation(summary = "게시글 수정")
    @PutMapping("/{postId}")
    public ResponseEntity<PostDto.PostResponse> updatePost(
            @PathVariable Long postId,
            @RequestParam Long userId,
            @Valid @RequestBody PostDto.UpdateRequest request) {
        return ResponseEntity.ok(postService.updatePost(postId, userId, request));
    }

    // 게시글 삭제 - 소프트 )
    @Operation(summary = "게시글 삭제(소프트)")
    @DeleteMapping("/{postId}")
    public ResponseEntity<Void> deletePost(
            @PathVariable Long postId,
            @RequestParam Long userId) {
        postService.deletePost(postId, userId);
        return ResponseEntity.noContent().build();
    }

    // 게시글 추천
    @Operation(summary = "게시글 추천")
    @PostMapping("/{postId}/upvote")
    public ResponseEntity<PostDto.PostResponse> upVotePost(
            @PathVariable Long postId) {
        return ResponseEntity.ok(postService.upVotePost(postId));
    }
}
