import SideItem from "./SideItem";

function HealthSidebar() {
  return (
    <aside className="w-[320px] bg-[#d3d3d3] px-7 py-12">
      <h3 className="mb-6 text-lg font-semibold text-[#1f2937]">건강 지표</h3>

      <div className="space-y-3 text-sm">
        <SideItem label="혈압" />
        <SideItem label="체중" />
        <SideItem label="혈당" />
        <SideItem label="운동" active />
        <SideItem label="약 복용" />
        <SideItem label="식단" />
      </div>

      <button className="mt-6 w-full rounded-full bg-[#0f1c33] py-3 text-sm font-semibold text-white">
        등록 하기
      </button>

      <div className="mt-10 rounded-xl bg-gradient-to-br from-[#0f4fd6] to-[#1d4ed8] p-4 text-white shadow-lg">
        <div className="mb-3 flex h-8 w-8 items-center justify-center rounded-md bg-white/20">
          ⭐
        </div>
        <p className="mb-3 text-sm font-bold">매우 훌륭한 추세입니다!</p>
        <p className="text-[11px] leading-5 text-white/85">
          이번 주 체중이 꾸준히 안정세를 보이고 있습니다. 현재의 식단과 수면
          패턴이 신체 밸런스에 긍정적인 영향을 주고 있는 것으로 분석됩니다.
        </p>

        <div className="mt-4 border-t border-white/20 pt-3">
          <p className="mb-2 text-[11px] text-white/70">전문가 추천 팁</p>
          <p className="text-[11px] leading-5 text-white/90">
            목표 체중까지 약 4.4kg 남았습니다. 근력 운동을 주 1회 더 추가하면
            기초대사량 향상에 도움이 됩니다.
          </p>
        </div>

        <button className="mt-4 w-full rounded-lg bg-white py-2 text-xs font-semibold text-[#1d4ed8]">
          맞춤형 식단 계획 보기
        </button>
      </div>

      <div className="mt-4 rounded-lg bg-[#eef2f7] p-3">
        <p className="mb-1 text-xs font-semibold text-[#374151]">
          수분 섭취 권장
        </p>
        <p className="text-[11px] leading-4 text-[#6b7280]">
          체중 감량 중에는 하루 2L 이상의 물을 마시는 것이 좋습니다.
        </p>
      </div>

      <div className="mt-8 flex justify-end">
        <button className="flex h-16 w-16 items-center justify-center rounded-full bg-[#0f1c33] text-white shadow-lg">
          ⭐
        </button>
      </div>
    </aside>
  );
}

export default HealthSidebar;
