function Pagination() {
  return (
    <div className="mt-6 flex items-center justify-center gap-4 text-xs text-gray-500">
      <button>{"<"}</button>
      <button className="flex h-7 w-7 items-center justify-center rounded-full bg-[#111827] text-white">
        1
      </button>
      <button>2</button>
      <button>3</button>
      <button>4</button>
      <button>5</button>
      <button>{">"}</button>
    </div>
  );
}

export default Pagination;
