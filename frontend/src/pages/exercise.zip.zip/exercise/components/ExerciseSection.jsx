import ExerciseCard from "./ExerciseCard";

function ExerciseSection({ icon, title, cards, progressWidth }) {
  return (
    <section className="mb-12">
      <div className="mb-4 flex items-center gap-2">
        <span className="text-base">{icon}</span>
        <h3 className="text-lg font-semibold text-[#1f2937]">{title}</h3>
      </div>

      <div className="rounded-2xl bg-white px-5 py-5 shadow-sm">
        <div className="grid grid-cols-3 gap-5">
          {cards.map((item, idx) => (
            <ExerciseCard key={idx} item={item} />
          ))}
        </div>

        <div className={`mt-5 h-1 rounded-full bg-gray-400 ${progressWidth}`} />
      </div>
    </section>
  );
}

export default ExerciseSection;
