import ExerciseHeader from "./components/ExerciseHeader";
import ExerciseSection from "./components/ExerciseSection";
import ExerciseRecordTable from "./components/ExerciseRecordTable";
import Pagination from "./components/Pagination";
import HealthSidebar from "./components/HealthSidebar";

function ExercisePage() {
  const strengthCards = [
    {
      name: "벤치 프레스",
      sets: "5 Sets",
      reps: "12회",
      intensity: "중간",
      kcal: "180 kcal",
      icon: "🏋️",
      type: "strength",
    },
    {
      name: "스쿼트",
      sets: "5 Sets",
      reps: "15회",
      intensity: "중간",
      kcal: "220 kcal",
      icon: "🏋️",
      type: "strength",
    },
    {
      name: "레그 프레스",
      sets: "5 Sets",
      reps: "15회",
      intensity: "중간",
      kcal: "220 kcal",
      icon: "🏋️",
      type: "strength",
    },
  ];

  const cardioCards = [
    {
      name: "사이클링",
      time: "25분",
      intensity: "중간",
      kcal: "150 kcal",
      icon: "🚲",
      type: "cardio",
    },
    {
      name: "러닝",
      time: "30분",
      intensity: "중간",
      kcal: "180 kcal",
      icon: "🏃",
      type: "cardio",
    },
    {
      name: "로잉",
      time: "20분",
      intensity: "중간",
      kcal: "140 kcal",
      icon: "🚣",
      type: "cardio",
    },
  ];

  const records = [1, 2, 3, 4];

  return (
    <div className="min-h-screen bg-[#d9d9d9] overflow-x-auto">
      <div className="mx-auto min-h-screen w-[1280px] bg-[#efefef]">
        <ExerciseHeader />

        <div className="flex">
          <main className="w-[1600px] px-20 py-12">
            <div className="mb-10 flex items-start justify-between">
              <h2 className="text-[40px] font-bold text-[#1f2937]">
                운동 기록 확인
              </h2>

              <div className="flex items-center gap-3 rounded-xl bg-white px-4 py-3 shadow-sm">
                <div className="rounded-md border border-gray-200 px-4 py-2 text-xs text-gray-700">
                  2026.04.01
                </div>
                <span className="text-sm text-gray-500">~</span>
                <div className="rounded-md border border-gray-200 px-4 py-2 text-xs text-gray-700">
                  2026.04.14
                </div>
                <button className="rounded-md bg-[#111827] px-4 py-2 text-xs text-white">
                  적용
                </button>
              </div>
            </div>

            <ExerciseSection
              icon="🏋️"
              title="무산소 운동 목록"
              cards={strengthCards}
              progressWidth="w-[240px]"
            />

            <ExerciseSection
              icon="🚴"
              title="유산소 운동"
              cards={cardioCards}
              progressWidth="w-[320px]"
            />

            <ExerciseRecordTable records={records} />
            <Pagination />
          </main>

          <HealthSidebar />
        </div>
      </div>
    </div>
  );
}

export default ExercisePage;
